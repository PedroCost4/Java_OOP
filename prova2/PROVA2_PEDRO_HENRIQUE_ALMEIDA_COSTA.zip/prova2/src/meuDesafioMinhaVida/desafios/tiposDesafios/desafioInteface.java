package meuDesafioMinhaVida.desafios.tiposDesafios;

public interface desafioInteface {
    
    public void finalizaAcao();
    public void aumentaSatisfacao();

}
